:- ensure_loaded('points1.pl').
:- ensure_loaded('util.pl').
:- ensure_loaded('levels.pl').
:- ensure_loaded('testing.pl').
:- ensure_loaded('checker.pl').

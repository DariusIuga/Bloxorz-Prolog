
vmpoints(Test, Points):-
        member(Test:Points,
               [
                        s0:20,
                        s1:20,
                        s3:20,
                        s4:30,
                        s6:30
              ]).
